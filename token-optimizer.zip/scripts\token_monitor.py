#!/usr/bin/env python3
"""
Token Monitor - AI对话Token使用实时监控脚本
版本: 1.0.0
作者: 工匠Agent
"""

import json
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional
from dataclasses import dataclass, asdict
from pathlib import Path


@dataclass
class TokenUsage:
    """Token使用记录"""
    timestamp: str
    session_id: str
    input_tokens: int
    output_tokens: int
    model: str
    cost_usd: float


@dataclass
class BudgetConfig:
    """预算配置"""
    daily_limit_k: float  # 千Token为单位
    warning_threshold: float  # 预警阈值 (0-1)
    auto_optimize: bool


class TokenMonitor:
    """Token监控器"""
    
    # 模型定价 (USD per 1K tokens)
    MODEL_PRICING = {
        "gpt-4": {"input": 0.03, "output": 0.06},
        "gpt-4-turbo": {"input": 0.01, "output": 0.03},
        "gpt-3.5-turbo": {"input": 0.0005, "output": 0.0015},
        "claude-3-opus": {"input": 0.015, "output": 0.075},
        "claude-3-sonnet": {"input": 0.003, "output": 0.015},
        "stepfun/step-alpha": {"input": 0.002, "output": 0.006},
    }
    
    def __init__(self, data_dir: str = "~/.token-optimizer"):
        self.data_dir = Path(data_dir).expanduser()
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.usage_file = self.data_dir / "usage_history.json"
        self.config_file = self.data_dir / "config.json"
        self._load_config()
    
    def _load_config(self):
        """加载配置"""
        if self.config_file.exists():
            with open(self.config_file, 'r', encoding='utf-8') as f:
                config = json.load(f)
                self.budget = BudgetConfig(**config.get('budget', {
                    'daily_limit_k': 1000,
                    'warning_threshold': 0.8,
                    'auto_optimize': False
                }))
        else:
            self.budget = BudgetConfig(
                daily_limit_k=1000,
                warning_threshold=0.8,
                auto_optimize=False
            )
            self._save_config()
    
    def _save_config(self):
        """保存配置"""
        with open(self.config_file, 'w', encoding='utf-8') as f:
            json.dump({'budget': asdict(self.budget)}, f, indent=2)
    
    def record_usage(self, session_id: str, input_tokens: int, 
                     output_tokens: int, model: str) -> TokenUsage:
        """记录Token使用"""
        pricing = self.MODEL_PRICING.get(model, self.MODEL_PRICING["gpt-3.5-turbo"])
        cost = (input_tokens * pricing["input"] + 
                output_tokens * pricing["output"]) / 1000
        
        usage = TokenUsage(
            timestamp=datetime.now().isoformat(),
            session_id=session_id,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            model=model,
            cost_usd=cost
        )
        
        # 追加到历史记录
        history = self._load_history()
        history.append(asdict(usage))
        
        with open(self.usage_file, 'w', encoding='utf-8') as f:
            json.dump(history, f, indent=2)
        
        return usage
    
    def _load_history(self) -> List[Dict]:
        """加载历史记录"""
        if self.usage_file.exists():
            with open(self.usage_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        return []
    
    def get_today_usage(self) -> Dict:
        """获取今日使用统计"""
        history = self._load_history()
        today = datetime.now().date()
        
        today_records = [
            r for r in history 
            if datetime.fromisoformat(r['timestamp']).date() == today
        ]
        
        total_input = sum(r['input_tokens'] for r in today_records)
        total_output = sum(r['output_tokens'] for r in today_records)
        total_cost = sum(r['cost_usd'] for r in today_records)
        
        budget_usage = (total_input + total_output) / (self.budget.daily_limit_k * 1000)
        
        return {
            'date': today.isoformat(),
            'total_tokens': total_input + total_output,
            'input_tokens': total_input,
            'output_tokens': total_output,
            'total_cost_usd': round(total_cost, 4),
            'total_cost_cny': round(total_cost * 7.2, 2),
            'budget_limit_k': self.budget.daily_limit_k,
            'budget_usage_percent': round(budget_usage * 100, 1),
            'session_count': len(set(r['session_id'] for r in today_records)),
            'should_warn': budget_usage >= self.budget.warning_threshold,
            'should_optimize': budget_usage >= 0.9
        }
    
    def get_usage_report(self, days: int = 7) -> Dict:
        """生成使用报告"""
        history = self._load_history()
        end_date = datetime.now().date()
        start_date = end_date - timedelta(days=days)
        
        daily_stats = {}
        for record in history:
            record_date = datetime.fromisoformat(record['timestamp']).date()
            if start_date <= record_date <= end_date:
                date_str = record_date.isoformat()
                if date_str not in daily_stats:
                    daily_stats[date_str] = {
                        'tokens': 0, 'cost_usd': 0, 'sessions': set()
                    }
                daily_stats[date_str]['tokens'] += record['input_tokens'] + record['output_tokens']
                daily_stats[date_str]['cost_usd'] += record['cost_usd']
                daily_stats[date_str]['sessions'].add(record['session_id'])
        
        # 转换为列表并计算平均值
        daily_list = []
        total_tokens = 0
        total_cost = 0
        
        for date_str, stats in sorted(daily_stats.items()):
            daily_list.append({
                'date': date_str,
                'tokens': stats['tokens'],
                'cost_usd': round(stats['cost_usd'], 4),
                'session_count': len(stats['sessions'])
            })
            total_tokens += stats['tokens']
            total_cost += stats['cost_usd']
        
        avg_daily = total_tokens / len(daily_list) if daily_list else 0
        projected_monthly = avg_daily * 30 / 1000  # 千Token为单位
        
        return {
            'period_days': days,
            'total_tokens': total_tokens,
            'total_cost_usd': round(total_cost, 4),
            'total_cost_cny': round(total_cost * 7.2, 2),
            'avg_daily_tokens': round(avg_daily, 0),
            'projected_monthly_cost_cny': round(projected_monthly * 0.01, 2),
            'daily_breakdown': daily_list,
            'optimization_potential': self._estimate_savings(total_tokens)
        }
    
    def _estimate_savings(self, total_tokens: int) -> Dict:
        """估算优化潜力"""
        # 基于典型压缩率估算
        conservative_savings = total_tokens * 0.30  # 30%
        aggressive_savings = total_tokens * 0.50    # 50%
        
        return {
            'conservative_percent': 30,
            'aggressive_percent': 50,
            'conservative_tokens': int(conservative_savings),
            'aggressive_tokens': int(aggressive_savings),
            'estimated_monthly_savings_cny': round(aggressive_savings / 1000 * 0.01 * 30 * 7.2, 2)
        }
    
    def set_budget(self, daily_limit_k: float, warning_threshold: float = 0.8):
        """设置预算"""
        self.budget.daily_limit_k = daily_limit_k
        self.budget.warning_threshold = warning_threshold
        self._save_config()
    
    def enable_auto_optimize(self, enabled: bool = True):
        """启用/禁用自动优化"""
        self.budget.auto_optimize = enabled
        self._save_config()


def main():
    """命令行入口"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Token Monitor')
    parser.add_argument('action', choices=['status', 'report', 'set-budget', 'record'])
    parser.add_argument('--days', type=int, default=7, help='报告天数')
    parser.add_argument('--budget', type=float, help='预算上限(千Token)')
    parser.add_argument('--session', help='会话ID')
    parser.add_argument('--input', type=int, help='输入Token数')
    parser.add_argument('--output', type=int, help='输出Token数')
    parser.add_argument('--model', default='gpt-3.5-turbo', help='模型名称')
    
    args = parser.parse_args()
    
    monitor = TokenMonitor()
    
    if args.action == 'status':
        status = monitor.get_today_usage()
        print(json.dumps(status, indent=2, ensure_ascii=False))
    
    elif args.action == 'report':
        report = monitor.get_usage_report(args.days)
        print(json.dumps(report, indent=2, ensure_ascii=False))
    
    elif args.action == 'set-budget':
        if args.budget:
            monitor.set_budget(args.budget)
            print(f"✅ 预算已设置为 {args.budget}K tokens/天")
        else:
            print("❌ 请使用 --budget 指定预算")
    
    elif args.action == 'record':
        if all([args.session, args.input, args.output]):
            usage = monitor.record_usage(
                args.session, args.input, args.output, args.model
            )
            print(f"✅ 已记录: {usage.input_tokens + usage.output_tokens} tokens")
            print(f"💰 成本: ${usage.cost_usd:.4f}")
        else:
            print("❌ 缺少必要参数: --session, --input, --output")


if __name__ == '__main__':
    main()

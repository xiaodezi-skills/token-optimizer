#!/usr/bin/env python3
"""
Token Optimizer - Conversation Compressor
对话压缩核心算法
"""

import re
from typing import List, Dict, Any
from dataclasses import dataclass

@dataclass
class Message:
    role: str
    content: str
    tokens: int = 0

class ConversationCompressor:
    """对话压缩器"""
    
    # 冗余模式定义
    REDUNDANT_PATTERNS = [
        r'^(好的|明白了|收到|了解|知道|嗯|哦|啊)[,.!?。！]*$',
        r'^(谢谢|感谢|多谢)[,.!?。！]*$',
        r'^(没问题|可以|行|OK|ok)[,.!?。！]*$',
        r'^(是的|对的|正确|没错)[,.!?。！]*$',
    ]
    
    # 保留标记
    KEEP_MARKER = '[KEEP]'
    
    def __init__(self, strategy: str = 'normal'):
        self.strategy = strategy
        self.strategies = {
            'light': {'threshold': 0.8, 'min_keep': 5},
            'normal': {'threshold': 0.6, 'min_keep': 3},
            'aggressive': {'threshold': 0.4, 'min_keep': 2}
        }
    
    def is_redundant(self, content: str) -> bool:
        """检查消息是否冗余"""
        content = content.strip()
        for pattern in self.REDUNDANT_PATTERNS:
            if re.match(pattern, content, re.IGNORECASE):
                return True
        return False
    
    def has_keep_marker(self, content: str) -> bool:
        """检查是否有保留标记"""
        return self.KEEP_MARKER in content
    
    def calculate_importance(self, message: Message) -> float:
        """计算消息重要性分数"""
        score = 0.5
        content = message.content
        
        # 有保留标记的重要性最高
        if self.has_keep_marker(content):
            score += 0.5
        
        # 长度适中的消息通常更重要
        length = len(content)
        if 100 < length < 1000:
            score += 0.2
        
        # 包含关键决策词
        decision_words = ['决定', '选择', '确认', '最终', '结论', '结果']
        if any(word in content for word in decision_words):
            score += 0.15
        
        # 包含代码或数据
        if '```' in content or '|' in content:
            score += 0.1
        
        # 冗余消息降低分数
        if self.is_redundant(content):
            score -= 0.4
        
        return max(0.0, min(1.0, score))
    
    def compress(self, messages: List[Message], keep_rounds: int = 3) -> List[Message]:
        """
        压缩对话历史
        
        Args:
            messages: 原始消息列表
            keep_rounds: 保留完整对话轮数
        
        Returns:
            压缩后的消息列表
        """
        if len(messages) <= keep_rounds * 2:
            return messages
        
        config = self.strategies.get(self.strategy, self.strategies['normal'])
        threshold = config['threshold']
        
        # 保留最近的几轮完整对话
        recent_messages = messages[-keep_rounds * 2:]
        old_messages = messages[:-keep_rounds * 2]
        
        # 计算旧消息的重要性
        scored_messages = []
        for msg in old_messages:
            importance = self.calculate_importance(msg)
            scored_messages.append((msg, importance))
        
        # 筛选重要消息
        important_messages = [
            msg for msg, score in scored_messages 
            if score >= threshold or self.has_keep_marker(msg.content)
        ]
        
        # 生成摘要消息
        summary = self._generate_summary(old_messages)
        if summary:
            summary_msg = Message(
                role='system',
                content=f"[前文摘要] {summary}",
                tokens=len(summary) // 4
            )
            return [summary_msg] + important_messages + recent_messages
        
        return important_messages + recent_messages
    
    def _generate_summary(self, messages: List[Message]) -> str:
        """生成对话摘要"""
        # 提取关键信息
        key_points = []
        
        for msg in messages:
            content = msg.content
            
            # 提取任务目标
            if '目标' in content or '目的' in content or '任务' in content:
                key_points.append(f"任务: {content[:50]}...")
            
            # 提取决策
            if any(word in content for word in ['决定', '选择', '确认']):
                key_points.append(f"决策: {content[:50]}...")
        
        if key_points:
            return ' | '.join(key_points[:3])
        
        return f"共 {len(messages)} 轮对话，涉及 {self._extract_topics(messages)}"
    
    def _extract_topics(self, messages: List[Message]) -> str:
        """提取对话主题"""
        all_content = ' '.join([m.content for m in messages])
        
        # 简单的关键词提取
        keywords = []
        if '代码' in all_content or 'function' in all_content:
            keywords.append('代码')
        if '数据' in all_content or '分析' in all_content:
            keywords.append('数据分析')
        if '配置' in all_content or '设置' in all_content:
            keywords.append('配置')
        if '问题' in all_content or 'bug' in all_content:
            keywords.append('问题排查')
        
        return '、'.join(keywords) if keywords else '一般对话'


def main():
    """CLI 入口"""
    import json
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: compressor.py <json_file> [--strategy=normal] [--keep-rounds=3]")
        sys.exit(1)
    
    file_path = sys.argv[1]
    strategy = 'normal'
    keep_rounds = 3
    
    for arg in sys.argv[2:]:
        if arg.startswith('--strategy='):
            strategy = arg.split('=')[1]
        elif arg.startswith('--keep-rounds='):
            keep_rounds = int(arg.split('=')[1])
    
    with open(file_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    messages = [Message(**m) for m in data.get('messages', [])]
    
    compressor = ConversationCompressor(strategy=strategy)
    compressed = compressor.compress(messages, keep_rounds=keep_rounds)
    
    result = {
        'original_count': len(messages),
        'compressed_count': len(compressed),
        'reduction_rate': (len(messages) - len(compressed)) / len(messages) * 100,
        'messages': [{'role': m.role, 'content': m.content} for m in compressed]
    }
    
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()

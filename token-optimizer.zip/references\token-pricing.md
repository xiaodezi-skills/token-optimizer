# Token 定价参考表

## OpenAI 模型

| 模型 | Input (每1K tokens) | Output (每1K tokens) | Context Window |
|------|---------------------|----------------------|----------------|
| GPT-4o | $0.005 | $0.015 | 128K |
| GPT-4o-mini | $0.00015 | $0.0006 | 128K |
| GPT-4 Turbo | $0.01 | $0.03 | 128K |
| GPT-3.5 Turbo | $0.0005 | $0.0015 | 16K |

## Anthropic 模型

| 模型 | Input (每1K tokens) | Output (每1K tokens) | Context Window |
|------|---------------------|----------------------|----------------|
| Claude 3 Opus | $0.015 | $0.075 | 200K |
| Claude 3 Sonnet | $0.003 | $0.015 | 200K |
| Claude 3 Haiku | $0.00025 | $0.00125 | 200K |

## 本地模型 (Ollama)

| 模型 | 成本 | 硬件要求 | 推荐场景 |
|------|------|----------|----------|
| Qwen 2.5 7B | 免费 | 8GB+ VRAM | 日常对话、简单任务 |
| Qwen 2.5 14B | 免费 | 16GB+ VRAM | 复杂推理、代码生成 |
| Llama 3.1 8B | 免费 | 8GB+ VRAM | 通用任务 |
| Llama 3.1 70B | 免费 | 48GB+ VRAM | 高级推理 |

## 成本对比示例

### 场景：1000 次对话，平均每次 2000 tokens

| 方案 | 单次成本 | 总成本 | 节省 |
|------|----------|--------|------|
| GPT-4o | $0.02 | $20.00 | - |
| GPT-4o-mini | $0.0005 | $0.50 | 97.5% |
| Claude 3 Haiku | $0.001 | $1.00 | 95% |
| 本地 Qwen 7B | $0 | $0 | 100% |

## 优化建议

1. **简单任务** (< 500 tokens): 使用 GPT-4o-mini 或本地模型
2. **中等任务** (500-2000 tokens): 使用 Claude 3 Haiku 或 GPT-3.5-turbo
3. **复杂任务** (> 2000 tokens): 使用 GPT-4o 或 Claude 3 Sonnet
4. **关键任务**: 使用 Claude 3 Opus 或 GPT-4 Turbo

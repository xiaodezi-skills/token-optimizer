#!/usr/bin/env python3
"""
Context Compressor - 压缩对话上下文，生成智能摘要
"""

import json
import re
from typing import Dict, List, Optional
from dataclasses import dataclass
from datetime import datetime

@dataclass
class CompressedContext:
    """压缩后的上下文"""
    summary: str
    key_points: List[str]
    retained_messages: List[Dict]
    removed_count: int
    savings_tokens: int

class ContextCompressor:
    """上下文压缩器"""
    
    def __init__(self, keep_recent: int = 5):
        """
        初始化压缩器
        
        Args:
            keep_recent: 保留最近的完整对话轮数
        """
        self.keep_recent = keep_recent
        
        # 低价值内容模式
        self.low_value_patterns = [
            r"^(好的|明白|了解|收到|OK|okay|嗯嗯|是的|没错)[,.!。！]*$",
            r"^(HEARTBEAT_OK|系统心跳|保持连接).*$",
            r"^(谢谢|感谢|多谢)[^\n]{0,20}$",
            r"^(不客气|不用谢|没事)[^\n]{0,20}$",
        ]
    
    def is_low_value(self, content: str) -> bool:
        """判断内容是否为低价值"""
        content = content.strip()
        if len(content) < 10:
            return True
        for pattern in self.low_value_patterns:
            if re.match(pattern, content, re.IGNORECASE):
                return True
        return False
    
    def extract_key_points(self, messages: List[Dict]) -> List[str]:
        """提取关键信息点"""
        key_points = []
        
        for msg in messages:
            content = msg.get("content", "")
            
            # 提取决策/结论
            decision_patterns = [
                r"(?:决定|确定|选择|采用|使用)\s*[:：]\s*([^\n]{10,100})",
                r"(?:结论是|结果是|最终|方案是)\s*[:：]\s*([^\n]{10,100})",
            ]
            for pattern in decision_patterns:
                matches = re.findall(pattern, content)
                key_points.extend(matches)
            
            # 提取配置/参数
            config_patterns = [
                r"(?:配置|设置|参数)\s*[:：]\s*([^\n]{10,100})",
                r"`([^`]{5,50})`\s*=\s*([^\n]{5,50})",
            ]
            for pattern in config_patterns:
                matches = re.findall(pattern, content)
                key_points.extend([f"{k}={v}" if isinstance(matches[0], tuple) else k 
                                  for k, v in matches] if matches and isinstance(matches[0], tuple) else matches)
            
            # 提取代码块
            code_blocks = re.findall(r"```[\w]*\n(.*?)```", content, re.DOTALL)
            for code in code_blocks[:2]:  # 最多保留2个代码块引用
                key_points.append(f"[代码片段] {code[:80]}...")
        
        # 去重和限制数量
        seen = set()
        unique_points = []
        for point in key_points:
            point_key = point[:50]
            if point_key not in seen and len(unique_points) < 10:
                seen.add(point_key)
                unique_points.append(point)
        
        return unique_points
    
    def generate_summary(self, messages: List[Dict]) -> str:
        """生成对话摘要"""
        # 提取用户目标和任务
        user_goals = []
        for msg in messages:
            if msg.get("role") == "user":
                content = msg.get("content", "")
                # 提取问题/请求
                if any(kw in content for kw in ["请", "帮我", "需要", "想要", "如何"]):
                    # 提取前100字符作为目标
                    goal = content[:100] + "..." if len(content) > 100 else content
                    user_goals.append(goal)
        
        # 构建摘要
        summary_parts = []
        if user_goals:
            summary_parts.append(f"用户目标: {user_goals[0]}")
        
        # 统计信息
        total_msgs = len(messages)
        user_msgs = len([m for m in messages if m.get("role") == "user"])
        assistant_msgs = total_msgs - user_msgs
        
        summary_parts.append(f"对话统计: {total_msgs} 轮 ({user_msgs} 用户, {assistant_msgs} 助手)")
        
        return " | ".join(summary_parts)
    
    def compress(self, messages: List[Dict]) -> CompressedContext:
        """
        压缩对话上下文
        
        策略：
        1. 保留最近 N 轮完整对话
        2. 压缩早期的低价值消息
        3. 提取关键信息点
        4. 生成摘要
        """
        if len(messages) <= self.keep_recent * 2:
            # 对话较短，无需压缩
            return CompressedContext(
                summary=self.generate_summary(messages),
                key_points=self.extract_key_points(messages),
                retained_messages=messages,
                removed_count=0,
                savings_tokens=0
            )
        
        # 保留最近的消息
        retained = messages[-self.keep_recent * 2:]
        
        # 处理早期的消息
        early_messages = messages[:-self.keep_recent * 2]
        
        # 过滤低价值消息
        valuable_early = [m for m in early_messages 
                         if not self.is_low_value(m.get("content", ""))]
        
        # 提取关键信息
        key_points = self.extract_key_points(valuable_early)
        
        # 生成摘要消息
        summary_content = self.generate_summary(valuable_early)
        if key_points:
            summary_content += "\n\n关键信息:\n" + "\n".join(f"- {p}" for p in key_points[:5])
        
        summary_msg = {
            "role": "system",
            "content": f"[上下文摘要] {summary_content}",
            "compressed": True,
            "original_count": len(early_messages)
        }
        
        # 合并保留的消息
        final_messages = [summary_msg] + retained
        
        # 计算节省
        original_chars = sum(len(m.get("content", "")) for m in messages)
        compressed_chars = sum(len(m.get("content", "")) for m in final_messages)
        savings = original_chars - compressed_chars
        
        return CompressedContext(
            summary=summary_content,
            key_points=key_points,
            retained_messages=final_messages,
            removed_count=len(early_messages) - 1,  # -1 for summary message
            savings_tokens=savings // 2  # 粗略估算
        )
    
    def compress_with_budget(self, messages: List[Dict], 
                            max_tokens: int = 4000) -> CompressedContext:
        """
        根据 Token 预算进行压缩
        
        Args:
            messages: 原始消息列表
            max_tokens: 最大允许的 Token 数
        """
        # 估算当前 Token 数
        current_chars = sum(len(m.get("content", "")) for m in messages)
        estimated_tokens = current_chars // 2
        
        if estimated_tokens <= max_tokens:
            return CompressedContext(
                summary="Token 使用在预算内，无需压缩",
                key_points=[],
                retained_messages=messages,
                removed_count=0,
                savings_tokens=0
            )
        
        # 需要压缩，动态调整保留轮数
        target_chars = max_tokens * 2
        ratio = target_chars / current_chars
        
        # 根据压缩比例调整保留轮数
        if ratio < 0.3:
            self.keep_recent = 3
        elif ratio < 0.5:
            self.keep_recent = 5
        else:
            self.keep_recent = 10
        
        return self.compress(messages)


def main():
    """命令行入口"""
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: python context_compressor.py <conversation.json> [keep_recent]")
        sys.exit(1)
    
    with open(sys.argv[1], 'r', encoding='utf-8') as f:
        messages = json.load(f)
    
    keep_recent = int(sys.argv[2]) if len(sys.argv) > 2 else 5
    
    compressor = ContextCompressor(keep_recent=keep_recent)
    result = compressor.compress(messages)
    
    output = {
        "summary": result.summary,
        "key_points": result.key_points,
        "removed_count": result.removed_count,
        "savings_tokens": result.savings_tokens,
        "retained_message_count": len(result.retained_messages),
        "messages": result.retained_messages
    }
    
    print(json.dumps(output, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()

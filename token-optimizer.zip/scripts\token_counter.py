#!/usr/bin/env python3
"""
Token Optimizer - Token Counter
Token 计数工具
"""

import re
from typing import List, Dict

class TokenCounter:
    """Token 计数器"""
    
    # 各模型的 token 比例（字符数 / tokens）
    MODEL_RATIOS = {
        'gpt-4': 4.0,
        'gpt-4o': 4.0,
        'gpt-3.5-turbo': 4.0,
        'claude-3-opus': 3.5,
        'claude-3-sonnet': 3.5,
        'claude-3-haiku': 3.5,
        'qwen': 3.8,
        'default': 4.0
    }
    
    # 中文模型通常每个汉字约等于 1 token
    CHINESE_CHARS_PER_TOKEN = 1.5
    
    @classmethod
    def count_tokens(cls, text: str, model: str = 'default') -> int:
        """
        估算文本的 token 数量
        
        Args:
            text: 输入文本
            model: 模型名称
        
        Returns:
            估算的 token 数量
        """
        if not text:
            return 0
        
        ratio = cls.MODEL_RATIOS.get(model, cls.MODEL_RATIOS['default'])
        
        # 分离中英文
        chinese_chars = len(re.findall(r'[\u4e00-\u9fff]', text))
        other_chars = len(text) - chinese_chars
        
        # 中文按字符计算，其他按字节比例
        chinese_tokens = chinese_chars / cls.CHINESE_CHARS_PER_TOKEN
        other_tokens = other_chars / ratio
        
        return int(chinese_tokens + other_tokens)
    
    @classmethod
    def count_messages(cls, messages: List[Dict], model: str = 'default') -> Dict:
        """
        计算消息列表的 token 统计
        
        Args:
            messages: 消息列表，每项包含 role 和 content
            model: 模型名称
        
        Returns:
            统计信息字典
        """
        total_tokens = 0
        message_stats = []
        
        for msg in messages:
            content = msg.get('content', '')
            tokens = cls.count_tokens(content, model)
            total_tokens += tokens
            
            message_stats.append({
                'role': msg.get('role', 'unknown'),
                'tokens': tokens,
                'length': len(content)
            })
        
        # 计算额外开销（消息格式开销，约 4 tokens 每条消息）
        overhead = len(messages) * 4
        total_tokens += overhead
        
        return {
            'total_tokens': total_tokens,
            'message_count': len(messages),
            'average_tokens': total_tokens / len(messages) if messages else 0,
            'overhead_tokens': overhead,
            'messages': message_stats
        }
    
    @classmethod
    def estimate_cost(cls, tokens: int, model: str = 'gpt-4') -> Dict:
        """
        估算 Token 成本
        
        Args:
            tokens: token 数量
            model: 模型名称
        
        Returns:
            成本估算
        """
        # 每 1K tokens 的价格（美元）
        PRICING = {
            'gpt-4': {'input': 0.03, 'output': 0.06},
            'gpt-4o': {'input': 0.005, 'output': 0.015},
            'gpt-3.5-turbo': {'input': 0.0005, 'output': 0.0015},
            'claude-3-opus': {'input': 0.015, 'output': 0.075},
            'claude-3-sonnet': {'input': 0.003, 'output': 0.015},
            'claude-3-haiku': {'input': 0.00025, 'output': 0.00125},
        }
        
        pricing = PRICING.get(model, PRICING['gpt-4'])
        
        # 假设 70% input, 30% output
        input_tokens = int(tokens * 0.7)
        output_tokens = tokens - input_tokens
        
        input_cost = (input_tokens / 1000) * pricing['input']
        output_cost = (output_tokens / 1000) * pricing['output']
        total_cost = input_cost + output_cost
        
        return {
            'model': model,
            'total_tokens': tokens,
            'estimated_cost_usd': round(total_cost, 4),
            'estimated_cost_cny': round(total_cost * 7.2, 4),
            'breakdown': {
                'input_tokens': input_tokens,
                'input_cost': round(input_cost, 4),
                'output_tokens': output_tokens,
                'output_cost': round(output_cost, 4)
            }
        }


def main():
    """CLI 入口"""
    import json
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: token_counter.py <text_or_file> [--model=gpt-4]")
        sys.exit(1)
    
    input_arg = sys.argv[1]
    model = 'gpt-4'
    
    for arg in sys.argv[2:]:
        if arg.startswith('--model='):
            model = arg.split('=')[1]
    
    # 尝试作为文件读取
    try:
        with open(input_arg, 'r', encoding='utf-8') as f:
            data = json.load(f)
            messages = data.get('messages', [])
            stats = TokenCounter.count_messages(messages, model)
            cost = TokenCounter.estimate_cost(stats['total_tokens'], model)
            
            result = {
                'stats': stats,
                'cost': cost
            }
            print(json.dumps(result, ensure_ascii=False, indent=2))
    except (FileNotFoundError, json.JSONDecodeError):
        # 作为纯文本处理
        text = input_arg
        tokens = TokenCounter.count_tokens(text, model)
        cost = TokenCounter.estimate_cost(tokens, model)
        
        result = {
            'text_length': len(text),
            'estimated_tokens': tokens,
            'cost': cost
        }
        print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()

#!/usr/bin/env python3
"""
Token Analyzer - 分析 Token 使用模式，识别优化点
"""

import json
import re
from typing import Dict, List, Tuple
from dataclasses import dataclass

@dataclass
class TokenUsage:
    """Token 使用统计"""
    total_tokens: int
    prompt_tokens: int
    completion_tokens: int
    message_count: int
    estimated_cost: float

@dataclass
class OptimizationOpportunity:
    """优化机会"""
    category: str
    description: str
    potential_savings: int
    priority: str  # high, medium, low

class TokenAnalyzer:
    """Token 使用分析器"""
    
    # 模型定价 (每 1K tokens)
    PRICING = {
        "gpt-4o": {"input": 0.0025, "output": 0.01},
        "gpt-4o-mini": {"input": 0.00015, "output": 0.0006},
        "claude-3-5-sonnet": {"input": 0.003, "output": 0.015},
        "qwen2.5-72b": {"input": 0.001, "output": 0.002},
        "qwen2.5-7b": {"input": 0.0001, "output": 0.0002},
    }
    
    def __init__(self):
        self.patterns = {
            "redundant_confirmations": r"(好的|明白|了解|收到|OK|okay)[,.!。！]*\s*",
            "system_noise": r"(HEARTBEAT_OK|系统心跳|保持连接)[,.!。！]*\s*",
            "repeated_greetings": r"(你好|您好|Hi|Hello)[,，!！]*\s*我是[^\n]{0,50}",
        }
    
    def analyze_conversation(self, messages: List[Dict]) -> TokenUsage:
        """分析对话 Token 使用情况"""
        total_chars = sum(len(m.get("content", "")) for m in messages)
        
        # 估算 tokens (粗略: 1 token ≈ 4 chars for Chinese, 4 chars for English)
        estimated_tokens = total_chars // 2
        prompt_tokens = int(estimated_tokens * 0.7)
        completion_tokens = int(estimated_tokens * 0.3)
        
        # 估算成本 (使用 gpt-4o-mini 作为参考)
        cost = (prompt_tokens / 1000 * 0.00015 + 
                completion_tokens / 1000 * 0.0006)
        
        return TokenUsage(
            total_tokens=estimated_tokens,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            message_count=len(messages),
            estimated_cost=cost
        )
    
    def find_optimization_opportunities(self, messages: List[Dict]) -> List[OptimizationOpportunity]:
        """识别优化机会"""
        opportunities = []
        content = "\n".join(m.get("content", "") for m in messages)
        
        # 检查冗余确认
        redundant_count = len(re.findall(self.patterns["redundant_confirmations"], content))
        if redundant_count > 5:
            opportunities.append(OptimizationOpportunity(
                category="冗余确认",
                description=f"发现 {redundant_count} 处冗余确认语句",
                potential_savings=redundant_count * 10,
                priority="medium"
            ))
        
        # 检查系统噪音
        noise_count = len(re.findall(self.patterns["system_noise"], content))
        if noise_count > 0:
            opportunities.append(OptimizationOpportunity(
                category="系统噪音",
                description=f"发现 {noise_count} 处系统心跳/保持连接消息",
                potential_savings=noise_count * 15,
                priority="high"
            ))
        
        # 检查重复问候
        greeting_count = len(re.findall(self.patterns["repeated_greetings"], content))
        if greeting_count > 2:
            opportunities.append(OptimizationOpportunity(
                category="重复问候",
                description=f"发现 {greeting_count} 处重复自我介绍",
                potential_savings=greeting_count * 50,
                priority="medium"
            ))
        
        # 检查长消息
        long_messages = [m for m in messages if len(m.get("content", "")) > 2000]
        if len(long_messages) > 3:
            opportunities.append(OptimizationOpportunity(
                category="长消息压缩",
                description=f"发现 {len(long_messages)} 条超长消息可摘要",
                potential_savings=len(long_messages) * 500,
                priority="high"
            ))
        
        return opportunities
    
    def generate_report(self, messages: List[Dict], model: str = "gpt-4o-mini") -> Dict:
        """生成 Token 分析报告"""
        usage = self.analyze_conversation(messages)
        opportunities = self.find_optimization_opportunities(messages)
        
        total_savings = sum(o.potential_savings for o in opportunities)
        savings_percent = (total_savings / usage.total_tokens * 100) if usage.total_tokens > 0 else 0
        
        # 计算优化后的成本
        pricing = self.PRICING.get(model, self.PRICING["gpt-4o-mini"])
        current_cost = (usage.prompt_tokens / 1000 * pricing["input"] + 
                       usage.completion_tokens / 1000 * pricing["output"])
        optimized_cost = current_cost * (1 - savings_percent / 100)
        
        return {
            "usage": {
                "total_tokens": usage.total_tokens,
                "message_count": usage.message_count,
                "estimated_cost_usd": round(current_cost, 4),
            },
            "optimization_opportunities": [
                {
                    "category": o.category,
                    "description": o.description,
                    "potential_savings": o.potential_savings,
                    "priority": o.priority
                }
                for o in opportunities
            ],
            "summary": {
                "total_potential_savings": total_savings,
                "savings_percentage": round(savings_percent, 1),
                "current_cost_usd": round(current_cost, 4),
                "optimized_cost_usd": round(optimized_cost, 4),
                "monthly_savings_potential_usd": round((current_cost - optimized_cost) * 30, 2)
            }
        }


def main():
    """命令行入口"""
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: python token_analyzer.py <conversation.json>")
        sys.exit(1)
    
    with open(sys.argv[1], 'r', encoding='utf-8') as f:
        messages = json.load(f)
    
    analyzer = TokenAnalyzer()
    report = analyzer.generate_report(messages)
    
    print(json.dumps(report, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()

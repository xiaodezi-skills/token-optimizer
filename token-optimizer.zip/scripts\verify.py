#!/usr/bin/env python3
"""
Token Optimizer 验证脚本
检查技能包的完整性和功能
"""

import json
import os
import sys
from pathlib import Path

class SkillVerifier:
    """技能验证器"""
    
    def __init__(self, skill_path: str):
        self.skill_path = Path(skill_path)
        self.errors = []
        self.warnings = []
        self.checks_passed = 0
    
    def verify(self) -> bool:
        """执行完整验证"""
        print("=" * 60)
        print("🔍 Token Optimizer 技能验证")
        print("=" * 60)
        
        # 1. 检查目录结构
        self._check_directory_structure()
        
        # 2. 检查 SKILL.md
        self._check_skill_md()
        
        # 3. 检查脚本
        self._check_scripts()
        
        # 4. 检查付费设置
        self._check_pricing()
        
        # 5. 检查依赖
        self._check_dependencies()
        
        # 输出结果
        print("\n" + "=" * 60)
        print("📋 验证结果")
        print("=" * 60)
        
        if self.errors:
            print(f"\n❌ 发现 {len(self.errors)} 个错误:")
            for error in self.errors:
                print(f"   - {error}")
        
        if self.warnings:
            print(f"\n⚠️  发现 {len(self.warnings)} 个警告:")
            for warning in self.warnings:
                print(f"   - {warning}")
        
        if not self.errors and not self.warnings:
            print(f"\n✅ 所有检查通过! ({self.checks_passed} 项)")
            return True
        elif not self.errors:
            print(f"\n✅ 核心检查通过，有 {len(self.warnings)} 个警告")
            return True
        else:
            print(f"\n❌ 验证失败，请修复错误后重试")
            return False
    
    def _check_directory_structure(self):
        """检查目录结构"""
        print("\n📁 检查目录结构...")
        
        required_dirs = ['scripts', 'references']
        optional_dirs = ['assets']
        
        for dir_name in required_dirs:
            dir_path = self.skill_path / dir_name
            if dir_path.exists():
                print(f"   ✅ {dir_name}/")
                self.checks_passed += 1
            else:
                self.errors.append(f"缺少必需目录: {dir_name}/")
        
        for dir_name in optional_dirs:
            dir_path = self.skill_path / dir_name
            if dir_path.exists():
                print(f"   ✅ {dir_name}/ (可选)")
                self.checks_passed += 1
    
    def _check_skill_md(self):
        """检查 SKILL.md"""
        print("\n📄 检查 SKILL.md...")
        
        skill_md_path = self.skill_path / "SKILL.md"
        if not skill_md_path.exists():
            self.errors.append("缺少 SKILL.md 文件")
            return
        
        with open(skill_md_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # 检查 YAML Frontmatter
        if content.startswith('---'):
            print("   ✅ YAML Frontmatter 存在")
            self.checks_passed += 1
        else:
            self.errors.append("SKILL.md 缺少 YAML Frontmatter")
        
        # 检查必需字段
        required_fields = ['name', 'description', 'version']
        for field in required_fields:
            if f"{field}:" in content:
                print(f"   ✅ 字段: {field}")
                self.checks_passed += 1
            else:
                self.errors.append(f"SKILL.md 缺少字段: {field}")
        
        # 检查内容章节
        required_sections = ['概述', '适用场景', '使用方法']
        for section in required_sections:
            if section in content:
                print(f"   ✅ 章节: {section}")
                self.checks_passed += 1
            else:
                self.warnings.append(f"SKILL.md 建议添加章节: {section}")
    
    def _check_scripts(self):
        """检查脚本"""
        print("\n🐍 检查脚本...")
        
        scripts_dir = self.skill_path / "scripts"
        if not scripts_dir.exists():
            return
        
        required_scripts = [
            'token_analyzer.py',
            'context_compressor.py',
            'cost_monitor.py',
            'optimizer_cli.py',
            'verify.py'
        ]
        
        for script_name in required_scripts:
            script_path = scripts_dir / script_name
            if script_path.exists():
                print(f"   ✅ {script_name}")
                self.checks_passed += 1
                
                # 检查是否为有效 Python 文件
                try:
                    with open(script_path, 'r', encoding='utf-8') as f:
                        compile(f.read(), script_name, 'exec')
                    print(f"      ✅ 语法有效")
                    self.checks_passed += 1
                except SyntaxError as e:
                    self.errors.append(f"{script_name} 语法错误: {e}")
            else:
                self.warnings.append(f"缺少脚本: {script_name}")
    
    def _check_pricing(self):
        """检查付费设置"""
        print("\n💰 检查付费设置...")
        
        skill_md_path = self.skill_path / "SKILL.md"
        with open(skill_md_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # 检查 price 字段
        if 'price:' in content:
            print("   ✅ price 字段已设置")
            self.checks_passed += 1
            
            # 提取价格
            import re
            price_match = re.search(r'price:\s*(\d+\.?\d*)', content)
            if price_match:
                price = float(price_match.group(1))
                print(f"   ✅ 定价: ¥{price}")
                self.checks_passed += 1
        else:
            self.errors.append("缺少 price 字段，未设置付费")
        
        # 检查 license 字段
        if 'license:' in content:
            print("   ✅ license 字段已设置")
            self.checks_passed += 1
        else:
            self.warnings.append("建议添加 license 字段")
    
    def _check_dependencies(self):
        """检查依赖"""
        print("\n📦 检查依赖...")
        
        # 检查 Python 版本
        if sys.version_info >= (3, 8):
            print(f"   ✅ Python {sys.version_info.major}.{sys.version_info.minor}")
            self.checks_passed += 1
        else:
            self.warnings.append(f"Python 版本较低: {sys.version_info.major}.{sys.version_info.minor}")
        
        # 检查标准库依赖
        std_libs = ['json', 'os', 'sys', 're', 'argparse', 'datetime', 'pathlib']
        for lib in std_libs:
            try:
                __import__(lib)
                print(f"   ✅ {lib}")
                self.checks_passed += 1
            except ImportError:
                self.errors.append(f"缺少标准库: {lib}")


def main():
    """主入口"""
    skill_path = sys.argv[1] if len(sys.argv) > 1 else "."
    
    verifier = SkillVerifier(skill_path)
    success = verifier.verify()
    
    # 生成验证报告
    report = {
        "skill_name": "token-optimizer",
        "version": "1.0.0",
        "verification_time": __import__('datetime').datetime.now().isoformat(),
        "checks_passed": verifier.checks_passed,
        "errors_count": len(verifier.errors),
        "warnings_count": len(verifier.warnings),
        "errors": verifier.errors,
        "warnings": verifier.warnings,
        "status": "passed" if success else "failed"
    }
    
    # 保存报告
    report_path = Path(skill_path) / "verification_report.json"
    with open(report_path, 'w', encoding='utf-8') as f:
        json.dump(report, f, indent=2, ensure_ascii=False)
    
    print(f"\n📝 验证报告已保存: {report_path}")
    
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()

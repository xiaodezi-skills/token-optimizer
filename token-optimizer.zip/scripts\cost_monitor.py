#!/usr/bin/env python3
"""
Cost Monitor - 实时监控 Token 成本和预算
"""

import json
import os
from typing import Dict, List, Optional
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta
from pathlib import Path

@dataclass
class BudgetConfig:
    """预算配置"""
    daily_limit: int = 10000  # 每日 Token 上限
    warning_threshold: float = 0.8  # 预警阈值 (80%)
    model_preference: str = "auto"  # auto, cheap, quality

@dataclass
class UsageRecord:
    """使用记录"""
    timestamp: str
    tokens_used: int
    cost_usd: float
    model: str
    task_type: str

@dataclass
class DailyStats:
    """每日统计"""
    date: str
    total_tokens: int
    total_cost_usd: float
    request_count: int
    model_breakdown: Dict[str, int]

class CostMonitor:
    """成本监控器"""
    
    # 模型定价 (每 1K tokens)
    PRICING = {
        "gpt-4o": {"input": 0.0025, "output": 0.01},
        "gpt-4o-mini": {"input": 0.00015, "output": 0.0006},
        "claude-3-5-sonnet": {"input": 0.003, "output": 0.015},
        "qwen2.5-72b": {"input": 0.001, "output": 0.002},
        "qwen2.5-7b": {"input": 0.0001, "output": 0.0002},
    }
    
    def __init__(self, data_dir: Optional[str] = None):
        """
        初始化监控器
        
        Args:
            data_dir: 数据存储目录
        """
        if data_dir is None:
            data_dir = os.path.expanduser("~/.stepclaw/token-monitor")
        
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        self.config_file = self.data_dir / "config.json"
        self.usage_file = self.data_dir / "usage.json"
        
        self.config = self._load_config()
        self.usage_history = self._load_usage()
    
    def _load_config(self) -> BudgetConfig:
        """加载配置"""
        if self.config_file.exists():
            with open(self.config_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return BudgetConfig(**data)
        return BudgetConfig()
    
    def _save_config(self):
        """保存配置"""
        with open(self.config_file, 'w', encoding='utf-8') as f:
            json.dump(asdict(self.config), f, indent=2)
    
    def _load_usage(self) -> List[UsageRecord]:
        """加载使用记录"""
        if self.usage_file.exists():
            with open(self.usage_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return [UsageRecord(**r) for r in data]
        return []
    
    def _save_usage(self):
        """保存使用记录"""
        with open(self.usage_file, 'w', encoding='utf-8') as f:
            json.dump([asdict(r) for r in self.usage_history], f, indent=2)
    
    def set_budget(self, daily_limit: int, warning_threshold: float = 0.8):
        """设置预算"""
        self.config.daily_limit = daily_limit
        self.config.warning_threshold = warning_threshold
        self._save_config()
        print(f"✅ 预算设置成功: 每日 {daily_limit} tokens, 预警阈值 {warning_threshold*100:.0f}%")
    
    def record_usage(self, tokens_used: int, model: str = "gpt-4o-mini", 
                    task_type: str = "general"):
        """记录使用"""
        pricing = self.PRICING.get(model, self.PRICING["gpt-4o-mini"])
        cost = tokens_used / 1000 * ((pricing["input"] + pricing["output"]) / 2)
        
        record = UsageRecord(
            timestamp=datetime.now().isoformat(),
            tokens_used=tokens_used,
            cost_usd=cost,
            model=model,
            task_type=task_type
        )
        
        self.usage_history.append(record)
        
        # 只保留最近 90 天的记录
        cutoff = datetime.now() - timedelta(days=90)
        self.usage_history = [
            r for r in self.usage_history 
            if datetime.fromisoformat(r.timestamp) > cutoff
        ]
        
        self._save_usage()
        
        # 检查预算
        self._check_budget()
    
    def _check_budget(self):
        """检查预算状态"""
        today = datetime.now().strftime("%Y-%m-%d")
        today_usage = sum(
            r.tokens_used for r in self.usage_history
            if r.timestamp.startswith(today)
        )
        
        usage_percent = today_usage / self.config.daily_limit
        
        if usage_percent >= 1.0:
            print(f"⚠️ 预算超限! 今日已使用 {today_usage}/{self.config.daily_limit} tokens ({usage_percent*100:.1f}%)")
        elif usage_percent >= self.config.warning_threshold:
            print(f"⚡ 预算预警: 今日已使用 {today_usage}/{self.config.daily_limit} tokens ({usage_percent*100:.1f}%)")
    
    def get_daily_stats(self, date: Optional[str] = None) -> DailyStats:
        """获取每日统计"""
        if date is None:
            date = datetime.now().strftime("%Y-%m-%d")
        
        day_records = [
            r for r in self.usage_history
            if r.timestamp.startswith(date)
        ]
        
        model_breakdown = {}
        for r in day_records:
            model_breakdown[r.model] = model_breakdown.get(r.model, 0) + r.tokens_used
        
        return DailyStats(
            date=date,
            total_tokens=sum(r.tokens_used for r in day_records),
            total_cost_usd=sum(r.cost_usd for r in day_records),
            request_count=len(day_records),
            model_breakdown=model_breakdown
        )
    
    def get_weekly_report(self) -> Dict:
        """获取周报"""
        today = datetime.now()
        week_start = today - timedelta(days=7)
        
        daily_stats = []
        for i in range(7):
            date = (week_start + timedelta(days=i)).strftime("%Y-%m-%d")
            stats = self.get_daily_stats(date)
            daily_stats.append({
                "date": stats.date,
                "tokens": stats.total_tokens,
                "cost_usd": round(stats.total_cost_usd, 4),
                "requests": stats.request_count
            })
        
        total_tokens = sum(d["tokens"] for d in daily_stats)
        total_cost = sum(d["cost_usd"] for d in daily_stats)
        
        return {
            "period": f"{week_start.strftime('%Y-%m-%d')} ~ {today.strftime('%Y-%m-%d')}",
            "daily_breakdown": daily_stats,
            "summary": {
                "total_tokens": total_tokens,
                "total_cost_usd": round(total_cost, 4),
                "avg_daily_tokens": total_tokens // 7,
                "projected_monthly_cost_usd": round(total_cost / 7 * 30, 2)
            }
        }
    
    def suggest_model(self, task_complexity: str = "auto") -> str:
        """根据任务复杂度和预算建议模型"""
        today = datetime.now().strftime("%Y-%m-%d")
        today_usage = sum(
            r.tokens_used for r in self.usage_history
            if r.timestamp.startswith(today)
        )
        
        remaining_budget = self.config.daily_limit - today_usage
        usage_percent = today_usage / self.config.daily_limit
        
        # 预算紧张时优先使用便宜模型
        if usage_percent > 0.9:
            return "qwen2.5-7b"  # 最便宜
        elif usage_percent > 0.7:
            return "gpt-4o-mini"  # 性价比高
        
        # 根据任务复杂度选择
        if task_complexity == "simple":
            return "qwen2.5-7b"
        elif task_complexity == "complex":
            return "gpt-4o"
        else:
            return "gpt-4o-mini"  # 默认平衡
    
    def get_status(self) -> Dict:
        """获取当前状态"""
        today = datetime.now().strftime("%Y-%m-%d")
        stats = self.get_daily_stats(today)
        
        usage_percent = stats.total_tokens / self.config.daily_limit if self.config.daily_limit > 0 else 0
        
        return {
            "date": today,
            "daily_limit": self.config.daily_limit,
            "used_today": stats.total_tokens,
            "remaining": max(0, self.config.daily_limit - stats.total_tokens),
            "usage_percent": round(usage_percent * 100, 1),
            "warning_threshold": self.config.warning_threshold * 100,
            "status": "over" if usage_percent >= 1.0 else "warning" if usage_percent >= self.config.warning_threshold else "ok"
        }


def main():
    """命令行入口"""
    import sys
    
    monitor = CostMonitor()
    
    if len(sys.argv) < 2:
        # 显示状态
        status = monitor.get_status()
        print(json.dumps(status, indent=2, ensure_ascii=False))
        return
    
    command = sys.argv[1]
    
    if command == "set-budget":
        limit = int(sys.argv[2]) if len(sys.argv) > 2 else 10000
        threshold = float(sys.argv[3]) if len(sys.argv) > 3 else 0.8
        monitor.set_budget(limit, threshold)
    
    elif command == "record":
        tokens = int(sys.argv[2]) if len(sys.argv) > 2 else 100
        model = sys.argv[3] if len(sys.argv) > 3 else "gpt-4o-mini"
        monitor.record_usage(tokens, model)
    
    elif command == "report":
        report = monitor.get_weekly_report()
        print(json.dumps(report, indent=2, ensure_ascii=False))
    
    elif command == "status":
        status = monitor.get_status()
        print(json.dumps(status, indent=2, ensure_ascii=False))
    
    elif command == "suggest":
        complexity = sys.argv[2] if len(sys.argv) > 2 else "auto"
        model = monitor.suggest_model(complexity)
        print(f"建议模型: {model}")
    
    else:
        print(f"Unknown command: {command}")
        print("Commands: set-budget, record, report, status, suggest")


if __name__ == "__main__":
    main()

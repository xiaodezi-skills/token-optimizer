#!/usr/bin/env python3
"""
Usage Analyzer - Token使用数据分析和报告生成脚本
版本: 1.0.0
作者: 工匠Agent
"""

import json
from typing import Dict, List, Any
from datetime import datetime, timedelta
from pathlib import Path
from collections import defaultdict


class UsageAnalyzer:
    """使用分析器"""
    
    def __init__(self, data_dir: str = "~/.token-optimizer"):
        self.data_dir = Path(data_dir).expanduser()
        self.usage_file = self.data_dir / "usage_history.json"
    
    def _load_history(self) -> List[Dict]:
        """加载历史数据"""
        if self.usage_file.exists():
            with open(self.usage_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        return []
    
    def generate_report(self, days: int = 7, format_type: str = 'markdown') -> str:
        """生成使用报告"""
        history = self._load_history()
        
        if not history:
            return "暂无使用数据"
        
        # 过滤日期范围
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days)
        
        filtered = [
            r for r in history
            if start_date <= datetime.fromisoformat(r['timestamp']) <= end_date
        ]
        
        # 统计分析
        stats = self._calculate_stats(filtered)
        trends = self._analyze_trends(filtered, days)
        insights = self._generate_insights(stats, trends)
        
        if format_type == 'markdown':
            return self._format_markdown_report(stats, trends, insights, days)
        elif format_type == 'json':
            return json.dumps({
                'stats': stats,
                'trends': trends,
                'insights': insights
            }, indent=2, ensure_ascii=False)
        else:
            return self._format_text_report(stats, trends, insights, days)
    
    def _calculate_stats(self, records: List[Dict]) -> Dict[str, Any]:
        """计算统计信息"""
        if not records:
            return {}
        
        total_tokens = sum(r['input_tokens'] + r['output_tokens'] for r in records)
        total_input = sum(r['input_tokens'] for r in records)
        total_output = sum(r['output_tokens'] for r in records)
        total_cost = sum(r['cost_usd'] for r in records)
        
        # 按模型统计
        by_model = defaultdict(lambda: {'tokens': 0, 'cost': 0, 'count': 0})
        for r in records:
            model = r.get('model', 'unknown')
            by_model[model]['tokens'] += r['input_tokens'] + r['output_tokens']
            by_model[model]['cost'] += r['cost_usd']
            by_model[model]['count'] += 1
        
        # 按日期统计
        by_date = defaultdict(lambda: {'tokens': 0, 'cost': 0})
        for r in records:
            date = r['timestamp'][:10]
            by_date[date]['tokens'] += r['input_tokens'] + r['output_tokens']
            by_date[date]['cost'] += r['cost_usd']
        
        return {
            'total_records': len(records),
            'total_tokens': total_tokens,
            'total_input_tokens': total_input,
            'total_output_tokens': total_output,
            'total_cost_usd': round(total_cost, 4),
            'total_cost_cny': round(total_cost * 7.2, 2),
            'avg_tokens_per_record': round(total_tokens / len(records), 0),
            'input_output_ratio': round(total_input / total_output, 2) if total_output > 0 else 0,
            'by_model': dict(by_model),
            'by_date': dict(by_date)
        }
    
    def _analyze_trends(self, records: List[Dict], days: int) -> Dict[str, Any]:
        """分析趋势"""
        if not records:
            return {}
        
        # 按日期聚合
        daily_usage = defaultdict(int)
        for r in records:
            date = r['timestamp'][:10]
            daily_usage[date] += r['input_tokens'] + r['output_tokens']
        
        dates = sorted(daily_usage.keys())
        usages = [daily_usage[d] for d in dates]
        
        if len(usages) < 2:
            return {'trend': 'stable', 'growth_rate': 0}
        
        # 计算增长率
        first_week = sum(usages[:min(3, len(usages))]) / min(3, len(usages)) if usages else 0
        last_week = sum(usages[-min(3, len(usages)):]) / min(3, len(usages)) if usages else 0
        
        growth_rate = ((last_week - first_week) / first_week * 100) if first_week > 0 else 0
        
        if growth_rate > 20:
            trend = 'increasing'
        elif growth_rate < -20:
            trend = 'decreasing'
        else:
            trend = 'stable'
        
        return {
            'trend': trend,
            'growth_rate': round(growth_rate, 1),
            'peak_day': max(daily_usage.items(), key=lambda x: x[1]) if daily_usage else None,
            'lowest_day': min(daily_usage.items(), key=lambda x: x[1]) if daily_usage else None,
            'daily_average': round(sum(usages) / len(usages), 0) if usages else 0
        }
    
    def _generate_insights(self, stats: Dict, trends: Dict) -> List[Dict]:
        """生成洞察建议"""
        insights = []
        
        if not stats:
            return insights
        
        # 成本洞察
        total_cost = stats.get('total_cost_cny', 0)
        if total_cost > 100:
            insights.append({
                'type': 'cost',
                'level': 'warning',
                'message': f'本期成本较高 (¥{total_cost})，建议启用自动优化',
                'action': '启用token-optimizer自动压缩功能'
            })
        
        # 趋势洞察
        trend = trends.get('trend', 'stable')
        growth = trends.get('growth_rate', 0)
        
        if trend == 'increasing':
            insights.append({
                'type': 'trend',
                'level': 'warning',
                'message': f'使用量呈上升趋势 (+{growth}%)，注意预算控制',
                'action': '检查是否有新的高消耗场景'
            })
        elif trend == 'decreasing':
            insights.append({
                'type': 'trend',
                'level': 'info',
                'message': f'使用量呈下降趋势 ({growth}%)，优化效果良好',
                'action': '继续保持当前使用习惯'
            })
        
        # 模型使用洞察
        by_model = stats.get('by_model', {})
        if len(by_model) > 1:
            most_used = max(by_model.items(), key=lambda x: x[1]['tokens'])
            insights.append({
                'type': 'model',
                'level': 'info',
                'message': f'主要使用模型: {most_used[0]} ({most_used[1]["tokens"]} tokens)',
                'action': '检查是否有更经济的替代模型'
            })
        
        # I/O比例洞察
        io_ratio = stats.get('input_output_ratio', 1)
        if io_ratio > 2:
            insights.append({
                'type': 'efficiency',
                'level': 'tip',
                'message': '输入Token远高于输出，提示词可能过长',
                'action': '优化提示词，删除不必要的上下文'
            })
        
        return insights
    
    def _format_markdown_report(self, stats: Dict, trends: Dict, insights: List, days: int) -> str:
        """格式化Markdown报告"""
        lines = [
            f"# Token使用报告 ({days}天)",
            f"",
            f"**生成时间**: {datetime.now().strftime('%Y-%m-%d %H:%M')}",
            f"",
            f"## 📊 概览",
            f"",
            f"| 指标 | 数值 |",
            f"|------|------|",
            f"| 总Token数 | {stats.get('total_tokens', 0):,} |",
            f"| 输入Token | {stats.get('total_input_tokens', 0):,} |",
            f"| 输出Token | {stats.get('total_output_tokens', 0):,} |",
            f"| 总成本 | ¥{stats.get('total_cost_cny', 0):.2f} |",
            f"| 平均每次 | {stats.get('avg_tokens_per_record', 0):.0f} tokens |",
            f"| 记录数 | {stats.get('total_records', 0)} |",
            f"",
            f"## 📈 趋势分析",
            f"",
        ]
        
        trend_emoji = {'increasing': '📈', 'decreasing': '📉', 'stable': '➡️'}
        trend = trends.get('trend', 'stable')
        lines.append(f"**趋势**: {trend_emoji.get(trend, '➡️')} {trend}")
        lines.append(f"**增长率**: {trends.get('growth_rate', 0)}%")
        lines.append(f"**日均使用**: {trends.get('daily_average', 0):,.0f} tokens")
        
        if trends.get('peak_day'):
            lines.append(f"**峰值日期**: {trends['peak_day'][0]} ({trends['peak_day'][1]:,} tokens)")
        
        lines.append("")
        lines.append("## 💡 优化建议")
        lines.append("")
        
        if insights:
            for insight in insights:
                level_emoji = {'warning': '⚠️', 'info': 'ℹ️', 'tip': '💡'}
                lines.append(f"{level_emoji.get(insight['level'], '•')} **{insight['message']}**")
                lines.append(f"   → {insight['action']}")
                lines.append("")
        else:
            lines.append("暂无优化建议")
        
        lines.append("")
        lines.append("## 📱 按模型统计")
        lines.append("")
        lines.append("| 模型 | Token数 | 成本 | 次数 |")
        lines.append("|------|---------|------|------|")
        
        by_model = stats.get('by_model', {})
        for model, data in sorted(by_model.items(), key=lambda x: x[1]['tokens'], reverse=True):
            lines.append(f"| {model} | {data['tokens']:,} | ${data['cost']:.4f} | {data['count']} |")
        
        lines.append("")
        lines.append("---")
        lines.append("*报告由 Token Optimizer 生成*")
        
        return '\n'.join(lines)
    
    def _format_text_report(self, stats: Dict, trends: Dict, insights: List, days: int) -> str:
        """格式化纯文本报告"""
        lines = [
            f"Token使用报告 ({days}天)",
            f"========================",
            f"",
            f"总Token: {stats.get('total_tokens', 0):,}",
            f"总成本: ¥{stats.get('total_cost_cny', 0):.2f}",
            f"趋势: {trends.get('trend', 'stable')} ({trends.get('growth_rate', 0)}%)",
            f"",
            f"优化建议:",
        ]
        
        for insight in insights:
            lines.append(f"- {insight['message']}")
        
        return '\n'.join(lines)


def main():
    """命令行入口"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Usage Analyzer')
    parser.add_argument('--days', '-d', type=int, default=7, help='报告天数')
    parser.add_argument('--format', '-f', choices=['markdown', 'json', 'text'], 
                        default='markdown', help='输出格式')
    parser.add_argument('--output', '-o', help='输出文件')
    
    args = parser.parse_args()
    
    analyzer = UsageAnalyzer()
    report = analyzer.generate_report(args.days, args.format)
    
    if args.output:
        with open(args.output, 'w', encoding='utf-8') as f:
            f.write(report)
        print(f"✅ 报告已保存: {args.output}")
    else:
        print(report)


if __name__ == '__main__':
    main()

#!/usr/bin/env python3
"""
Budget Manager - Token预算管理和预警脚本
版本: 1.0.0
作者: 工匠Agent
"""

import json
import sys
from typing import Dict, Optional
from dataclasses import dataclass, asdict
from pathlib import Path
from datetime import datetime, timedelta


@dataclass
class BudgetAlert:
    """预算预警"""
    level: str  # 'info', 'warning', 'critical'
    message: str
    current_usage: float
    threshold: float
    timestamp: str


class BudgetManager:
    """预算管理器"""
    
    ALERT_LEVELS = {
        'info': {'emoji': 'ℹ️', 'color': 'blue'},
        'warning': {'emoji': '⚠️', 'color': 'yellow'},
        'critical': {'emoji': '🚨', 'color': 'red'}
    }
    
    def __init__(self, data_dir: str = "~/.token-optimizer"):
        self.data_dir = Path(data_dir).expanduser()
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.config_file = self.data_dir / "budget_config.json"
        self.alert_file = self.data_dir / "alerts.json"
        self._load_config()
    
    def _load_config(self):
        """加载配置"""
        if self.config_file.exists():
            with open(self.config_file, 'r', encoding='utf-8') as f:
                self.config = json.load(f)
        else:
            self.config = {
                'daily_budget_k': 1000,  # 千Token
                'monthly_budget_k': 30000,
                'warning_threshold': 0.8,
                'critical_threshold': 0.95,
                'auto_optimize_at': 0.9,
                'notifications_enabled': True,
                'email_alerts': False,
                'webhook_url': None
            }
            self._save_config()
    
    def _save_config(self):
        """保存配置"""
        with open(self.config_file, 'w', encoding='utf-8') as f:
            json.dump(self.config, f, indent=2)
    
    def set_budget(self, daily_k: Optional[float] = None, 
                   monthly_k: Optional[float] = None,
                   warning_threshold: Optional[float] = None):
        """设置预算"""
        if daily_k is not None:
            self.config['daily_budget_k'] = daily_k
        if monthly_k is not None:
            self.config['monthly_budget_k'] = monthly_k
        if warning_threshold is not None:
            self.config['warning_threshold'] = warning_threshold
        
        self._save_config()
        return self.config
    
    def check_budget(self, current_usage_k: float) -> Optional[BudgetAlert]:
        """检查预算状态"""
        daily_budget = self.config['daily_budget_k']
        usage_ratio = current_usage_k / daily_budget if daily_budget > 0 else 0
        
        if usage_ratio >= self.config['critical_threshold']:
            return BudgetAlert(
                level='critical',
                message=f'🚨 预算紧急！已使用 {usage_ratio*100:.1f}% ({current_usage_k:.1f}K / {daily_budget}K)',
                current_usage=current_usage_k,
                threshold=self.config['critical_threshold'],
                timestamp=datetime.now().isoformat()
            )
        elif usage_ratio >= self.config['warning_threshold']:
            return BudgetAlert(
                level='warning',
                message=f'⚠️ 预算预警！已使用 {usage_ratio*100:.1f}% ({current_usage_k:.1f}K / {daily_budget}K)',
                current_usage=current_usage_k,
                threshold=self.config['warning_threshold'],
                timestamp=datetime.now().isoformat()
            )
        elif usage_ratio >= self.config.get('auto_optimize_at', 0.9):
            return BudgetAlert(
                level='info',
                message=f'ℹ️ 建议优化：已使用 {usage_ratio*100:.1f}%，即将达到预算上限',
                current_usage=current_usage_k,
                threshold=self.config.get('auto_optimize_at', 0.9),
                timestamp=datetime.now().isoformat()
            )
        
        return None
    
    def get_budget_status(self, current_usage_k: float) -> Dict:
        """获取预算状态"""
        daily_budget = self.config['daily_budget_k']
        monthly_budget = self.config['monthly_budget_k']
        
        daily_ratio = current_usage_k / daily_budget if daily_budget > 0 else 0
        
        # 估算月度使用（基于当前日使用量）
        days_in_month = 30
        projected_monthly = current_usage_k * days_in_month
        monthly_ratio = projected_monthly / monthly_budget if monthly_budget > 0 else 0
        
        return {
            'daily': {
                'budget_k': daily_budget,
                'used_k': round(current_usage_k, 2),
                'remaining_k': round(daily_budget - current_usage_k, 2),
                'usage_percent': round(daily_ratio * 100, 1),
                'status': self._get_status_text(daily_ratio)
            },
            'monthly': {
                'budget_k': monthly_budget,
                'projected_k': round(projected_monthly, 2),
                'usage_percent': round(monthly_ratio * 100, 1),
                'status': self._get_status_text(monthly_ratio)
            },
            'thresholds': {
                'warning': self.config['warning_threshold'],
                'critical': self.config['critical_threshold'],
                'auto_optimize': self.config.get('auto_optimize_at', 0.9)
            }
        }
    
    def _get_status_text(self, ratio: float) -> str:
        """获取状态文本"""
        if ratio >= self.config['critical_threshold']:
            return 'critical'
        elif ratio >= self.config['warning_threshold']:
            return 'warning'
        elif ratio >= self.config.get('auto_optimize_at', 0.9):
            return 'caution'
        else:
            return 'normal'
    
    def should_optimize(self, current_usage_k: float) -> bool:
        """判断是否应该触发优化"""
        daily_budget = self.config['daily_budget_k']
        usage_ratio = current_usage_k / daily_budget if daily_budget > 0 else 0
        return usage_ratio >= self.config.get('auto_optimize_at', 0.9)
    
    def get_recommendations(self, current_usage_k: float) -> list:
        """获取优化建议"""
        recommendations = []
        daily_budget = self.config['daily_budget_k']
        usage_ratio = current_usage_k / daily_budget if daily_budget > 0 else 0
        
        if usage_ratio >= 0.95:
            recommendations.append({
                'priority': 'high',
                'action': '立即启用激进压缩模式',
                'description': 'Token使用已接近上限，建议启用最大压缩率',
                'potential_savings': '40-50%'
            })
            recommendations.append({
                'priority': 'high',
                'action': '清理历史会话',
                'description': '删除或压缩旧会话以释放Token预算',
                'potential_savings': '20-30%'
            })
        elif usage_ratio >= 0.8:
            recommendations.append({
                'priority': 'medium',
                'action': '启用自动优化',
                'description': '开启自动压缩功能，保持Token使用在合理范围',
                'potential_savings': '30-40%'
            })
            recommendations.append({
                'priority': 'medium',
                'action': '检查长会话',
                'description': '识别并优化Token消耗较高的会话',
                'potential_savings': '15-25%'
            })
        elif usage_ratio >= 0.5:
            recommendations.append({
                'priority': 'low',
                'action': '监控使用趋势',
                'description': '关注Token使用增长趋势，提前规划',
                'potential_savings': '10-15%'
            })
        
        return recommendations


def main():
    """命令行入口"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Budget Manager')
    parser.add_argument('action', choices=['set', 'check', 'status', 'recommend'])
    parser.add_argument('--daily', '-d', type=float, help='日预算(千Token)')
    parser.add_argument('--monthly', '-m', type=float, help='月预算(千Token)')
    parser.add_argument('--threshold', '-t', type=float, help='预警阈值(0-1)')
    parser.add_argument('--current', '-c', type=float, help='当前使用量(千Token)')
    
    args = parser.parse_args()
    
    manager = BudgetManager()
    
    if args.action == 'set':
        config = manager.set_budget(
            daily_k=args.daily,
            monthly_k=args.monthly,
            warning_threshold=args.threshold
        )
        print("✅ 预算设置已更新")
        print(f"   日预算: {config['daily_budget_k']}K tokens")
        print(f"   月预算: {config['monthly_budget_k']}K tokens")
        print(f"   预警阈值: {config['warning_threshold']*100}%")
    
    elif args.action == 'check':
        if args.current is None:
            print("❌ 请指定当前使用量: --current")
            return
        
        alert = manager.check_budget(args.current)
        if alert:
            emoji = manager.ALERT_LEVELS[alert.level]['emoji']
            print(f"{emoji} {alert.message}")
            print(f"   当前: {alert.current_usage:.1f}K")
            print(f"   阈值: {alert.threshold*100}%")
        else:
            print(f"✅ 预算正常 ({args.current:.1f}K / {manager.config['daily_budget_k']}K)")
    
    elif args.action == 'status':
        if args.current is None:
            print("❌ 请指定当前使用量: --current")
            return
        
        status = manager.get_budget_status(args.current)
        print(json.dumps(status, indent=2, ensure_ascii=False))
    
    elif args.action == 'recommend':
        if args.current is None:
            print("❌ 请指定当前使用量: --current")
            return
        
        recommendations = manager.get_recommendations(args.current)
        print("💡 优化建议:")
        for rec in recommendations:
            priority_emoji = {'high': '🔴', 'medium': '🟡', 'low': '🟢'}[rec['priority']]
            print(f"\n{priority_emoji} {rec['action']}")
            print(f"   {rec['description']}")
            print(f"   预计节省: {rec['potential_savings']}")


if __name__ == '__main__':
    main()

# Token 定价参考表

## 主流模型定价 (每 1K tokens)

| 模型 | Input | Output | 备注 |
|------|-------|--------|------|
| **OpenAI** |
| GPT-4o | $0.0025 | $0.01 | 高性能，适合复杂任务 |
| GPT-4o-mini | $0.00015 | $0.0006 | 性价比之选 |
| GPT-3.5-turbo | $0.0005 | $0.0015 | 经济型 |
| **Anthropic** |
| Claude 3.5 Sonnet | $0.003 | $0.015 | 推理能力强 |
| Claude 3 Haiku | $0.00025 | $0.00125 | 快速响应 |
| **Qwen (通义千问)** |
| Qwen2.5-72B | $0.001 | $0.002 | 中文优化 |
| Qwen2.5-7B | $0.0001 | $0.0002 | 本地部署友好 |
| **StepFun** |
| Step-1 | ¥0.004 | ¥0.004 | 国产模型 |
| Step-2 | ¥0.008 | ¥0.008 | 增强版 |

## 成本对比示例

### 场景：1000 次对话，平均每次 2000 tokens

| 模型 | 单次成本 | 1000次成本 | 月度成本(30天) |
|------|----------|------------|----------------|
| GPT-4o | $0.005 | $5.00 | $150 |
| GPT-4o-mini | $0.0003 | $0.30 | $9 |
| Qwen2.5-7B | $0.0001 | $0.10 | $3 |

## 优化建议

### 1. 模型选择策略

- **简单任务** (翻译、摘要、格式化) → Qwen2.5-7B / GPT-4o-mini
- **中等任务** (代码生成、数据分析) → GPT-4o-mini / Qwen2.5-72B
- **复杂任务** (推理、创意写作) → GPT-4o / Claude 3.5 Sonnet

### 2. Token 优化技巧

1. **精简 Prompt**
   - 删除冗余说明
   - 使用简洁的指令格式
   - 避免重复示例

2. **上下文管理**
   - 定期清理历史
   - 使用摘要替代完整历史
   - 只保留相关上下文

3. **响应控制**
   - 设置 max_tokens 限制
   - 要求简洁回答
   - 使用结构化输出

## 参考链接

- [OpenAI Pricing](https://openai.com/pricing)
- [Anthropic Pricing](https://www.anthropic.com/pricing)
- [Qwen Pricing](https://help.aliyun.com/zh/dashscope/developer-reference/tongyi-thousand-questions-metering-and-billing)

#!/usr/bin/env python3
"""
Token Optimizer CLI - 命令行工具，支持批量优化
"""

import argparse
import json
import sys
from pathlib import Path
from typing import Optional

# 导入其他模块
from token_analyzer import TokenAnalyzer
from context_compressor import ContextCompressor
from cost_monitor import CostMonitor

class OptimizerCLI:
    """Token Optimizer 命令行界面"""
    
    def __init__(self):
        self.analyzer = TokenAnalyzer()
        self.compressor = ContextCompressor()
        self.monitor = CostMonitor()
    
    def analyze(self, conversation_file: str, output: Optional[str] = None):
        """分析对话 Token 使用情况"""
        with open(conversation_file, 'r', encoding='utf-8') as f:
            messages = json.load(f)
        
        report = self.analyzer.generate_report(messages)
        
        # 格式化输出
        print("=" * 60)
        print("📊 Token 使用分析报告")
        print("=" * 60)
        print(f"\n总 Token 数: {report['usage']['total_tokens']:,}")
        print(f"消息数量: {report['usage']['message_count']}")
        print(f"预估成本: ${report['usage']['estimated_cost_usd']:.4f}")
        
        if report['optimization_opportunities']:
            print(f"\n🔍 发现 {len(report['optimization_opportunities'])} 个优化机会:")
            for opp in report['optimization_opportunities']:
                icon = "🔴" if opp['priority'] == 'high' else "🟡" if opp['priority'] == 'medium' else "🟢"
                print(f"  {icon} [{opp['category']}] {opp['description']}")
                print(f"      可节省: ~{opp['potential_savings']} tokens")
        
        print(f"\n💰 成本优化潜力:")
        print(f"  可节省: {report['summary']['savings_percentage']:.1f}% ({report['summary']['total_potential_savings']:,} tokens)")
        print(f"  当前成本: ${report['summary']['current_cost_usd']:.4f}")
        print(f"  优化后: ${report['summary']['optimized_cost_usd']:.4f}")
        print(f"  月度节省潜力: ${report['summary']['monthly_savings_potential_usd']:.2f}")
        
        if output:
            with open(output, 'w', encoding='utf-8') as f:
                json.dump(report, f, indent=2, ensure_ascii=False)
            print(f"\n✅ 报告已保存: {output}")
    
    def compress(self, conversation_file: str, keep_recent: int = 5, 
                output: Optional[str] = None):
        """压缩对话上下文"""
        with open(conversation_file, 'r', encoding='utf-8') as f:
            messages = json.load(f)
        
        self.compressor.keep_recent = keep_recent
        result = self.compressor.compress(messages)
        
        print("=" * 60)
        print("🗜️  上下文压缩结果")
        print("=" * 60)
        print(f"\n摘要: {result.summary}")
        
        if result.key_points:
            print(f"\n📌 关键信息点:")
            for i, point in enumerate(result.key_points[:5], 1):
                print(f"  {i}. {point[:80]}...")
        
        print(f"\n📊 压缩统计:")
        print(f"  原消息数: {len(messages)}")
        print(f"  保留消息数: {len(result.retained_messages)}")
        print(f"  删除消息数: {result.removed_count}")
        print(f"  节省 Tokens: ~{result.savings_tokens:,}")
        print(f"  压缩率: {result.savings_tokens / (len(messages) * 100) * 100:.1f}%")
        
        if output:
            with open(output, 'w', encoding='utf-8') as f:
                json.dump({
                    "summary": result.summary,
                    "key_points": result.key_points,
                    "messages": result.retained_messages
                }, f, indent=2, ensure_ascii=False)
            print(f"\n✅ 压缩结果已保存: {output}")
    
    def budget(self, command: str, *args):
        """预算管理"""
        if command == "set":
            limit = int(args[0]) if args else 10000
            threshold = float(args[1]) if len(args) > 1 else 0.8
            self.monitor.set_budget(limit, threshold)
        
        elif command == "status":
            status = self.monitor.get_status()
            print("=" * 60)
            print("💰 预算状态")
            print("=" * 60)
            print(f"\n日期: {status['date']}")
            print(f"每日限额: {status['daily_limit']:,} tokens")
            print(f"今日已用: {status['used_today']:,} tokens")
            print(f"剩余额度: {status['remaining']:,} tokens")
            
            bar_width = 40
            filled = int(status['usage_percent'] / 100 * bar_width)
            bar = "█" * filled + "░" * (bar_width - filled)
            
            if status['status'] == 'over':
                icon = "🔴"
            elif status['status'] == 'warning':
                icon = "🟡"
            else:
                icon = "🟢"
            
            print(f"\n使用进度: {icon} [{bar}] {status['usage_percent']:.1f}%")
        
        elif command == "report":
            report = self.monitor.get_weekly_report()
            print("=" * 60)
            print("📈 周报")
            print("=" * 60)
            print(f"\n统计周期: {report['period']}")
            print(f"\n总 Token 数: {report['summary']['total_tokens']:,}")
            print(f"总成本: ${report['summary']['total_cost_usd']:.4f}")
            print(f"日均使用: {report['summary']['avg_daily_tokens']:,} tokens")
            print(f"预估月成本: ${report['summary']['projected_monthly_cost_usd']:.2f}")
            
            print(f"\n每日明细:")
            for day in report['daily_breakdown']:
                print(f"  {day['date']}: {day['tokens']:>8,} tokens | ${day['cost_usd']:>7.4f} | {day['requests']:>3} 次")
        
        elif command == "suggest":
            complexity = args[0] if args else "auto"
            model = self.monitor.suggest_model(complexity)
            print(f"🤖 根据当前预算和任务复杂度，建议使用: {model}")
    
    def auto(self, conversation_file: str, max_tokens: int = 4000):
        """自动优化：分析 + 压缩 + 预算检查"""
        print("🚀 启动自动优化流程...\n")
        
        # 1. 分析
        print("📊 步骤 1/3: 分析 Token 使用情况...")
        with open(conversation_file, 'r', encoding='utf-8') as f:
            messages = json.load(f)
        report = self.analyzer.generate_report(messages)
        
        print(f"   当前使用: {report['usage']['total_tokens']:,} tokens")
        print(f"   优化潜力: {report['summary']['savings_percentage']:.1f}%")
        
        # 2. 检查预算
        print("\n💰 步骤 2/3: 检查预算状态...")
        status = self.monitor.get_status()
        print(f"   今日已用: {status['used_today']:,} / {status['daily_limit']:,} tokens")
        
        # 3. 压缩
        print("\n🗜️  步骤 3/3: 压缩上下文...")
        result = self.compressor.compress_with_budget(messages, max_tokens)
        print(f"   原消息: {len(messages)} 条")
        print(f"   压缩后: {len(result.retained_messages)} 条")
        print(f"   节省: ~{result.savings_tokens:,} tokens")
        
        print("\n" + "=" * 60)
        print("✅ 自动优化完成!")
        print("=" * 60)
        print(f"\n建议操作:")
        print(f"  1. 使用压缩后的上下文继续对话")
        print(f"  2. 考虑使用更经济的模型: {self.monitor.suggest_model()}")
        print(f"  3. 设置预算预警: optimizer budget set {status['daily_limit']}")


def main():
    """主入口"""
    parser = argparse.ArgumentParser(
        description="Token Optimizer CLI - AI对话Token智能优化工具",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  optimizer analyze conversation.json
  optimizer compress conversation.json --keep 5 -o compressed.json
  optimizer budget status
  optimizer budget set 10000 0.8
  optimizer auto conversation.json --max-tokens 4000
        """
    )
    
    subparsers = parser.add_subparsers(dest="command", help="可用命令")
    
    # analyze 命令
    analyze_parser = subparsers.add_parser("analyze", help="分析 Token 使用情况")
    analyze_parser.add_argument("file", help="对话 JSON 文件")
    analyze_parser.add_argument("-o", "--output", help="输出报告文件")
    
    # compress 命令
    compress_parser = subparsers.add_parser("compress", help="压缩对话上下文")
    compress_parser.add_argument("file", help="对话 JSON 文件")
    compress_parser.add_argument("-k", "--keep", type=int, default=5, help="保留最近轮数")
    compress_parser.add_argument("-o", "--output", help="输出文件")
    
    # budget 命令
    budget_parser = subparsers.add_parser("budget", help="预算管理")
    budget_parser.add_argument("action", choices=["set", "status", "report", "suggest"])
    budget_parser.add_argument("args", nargs="*", help="参数")
    
    # auto 命令
    auto_parser = subparsers.add_parser("auto", help="自动优化")
    auto_parser.add_argument("file", help="对话 JSON 文件")
    auto_parser.add_argument("--max-tokens", type=int, default=4000, help="最大 Token 限制")
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return
    
    cli = OptimizerCLI()
    
    if args.command == "analyze":
        cli.analyze(args.file, args.output)
    elif args.command == "compress":
        cli.compress(args.file, args.keep, args.output)
    elif args.command == "budget":
        cli.budget(args.action, *args.args)
    elif args.command == "auto":
        cli.auto(args.file, args.max_tokens)


if __name__ == "__main__":
    main()

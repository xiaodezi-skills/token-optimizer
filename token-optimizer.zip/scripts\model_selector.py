#!/usr/bin/env python3
"""
Token Optimizer - Model Selector
智能模型选择器
"""

from typing import Dict, List, Optional
from dataclasses import dataclass
from enum import Enum

class TaskComplexity(Enum):
    """任务复杂度等级"""
    SIMPLE = 1
    MODERATE = 2
    COMPLEX = 3
    VERY_COMPLEX = 4

@dataclass
class ModelInfo:
    """模型信息"""
    name: str
    provider: str
    cost_per_1k_input: float  # USD
    cost_per_1k_output: float  # USD
    context_window: int
    strengths: List[str]
    weaknesses: List[str]
    complexity_rating: TaskComplexity

class ModelSelector:
    """智能模型选择器"""
    
    # 模型库
    MODELS = {
        'qwen2.5:7b': ModelInfo(
            name='qwen2.5:7b',
            provider='ollama',
            cost_per_1k_input=0,
            cost_per_1k_output=0,
            context_window=32768,
            strengths=['本地运行', '免费', '中文优秀', '速度快'],
            weaknesses=['复杂推理能力有限', '代码能力一般'],
            complexity_rating=TaskComplexity.SIMPLE
        ),
        'qwen2.5:14b': ModelInfo(
            name='qwen2.5:14b',
            provider='ollama',
            cost_per_1k_input=0,
            cost_per_1k_output=0,
            context_window=32768,
            strengths=['本地运行', '免费', '中文优秀', '推理能力较好'],
            weaknesses=['需要更多显存', '速度较慢'],
            complexity_rating=TaskComplexity.MODERATE
        ),
        'gpt-3.5-turbo': ModelInfo(
            name='gpt-3.5-turbo',
            provider='openai',
            cost_per_1k_input=0.0005,
            cost_per_1k_output=0.0015,
            context_window=16385,
            strengths=['性价比高', '速度快', '通用能力强'],
            weaknesses=['复杂推理不如 GPT-4'],
            complexity_rating=TaskComplexity.MODERATE
        ),
        'gpt-4o-mini': ModelInfo(
            name='gpt-4o-mini',
            provider='openai',
            cost_per_1k_input=0.00015,
            cost_per_1k_output=0.0006,
            context_window=128000,
            strengths=['成本极低', '速度快', '多模态'],
            weaknesses=['复杂任务能力有限'],
            complexity_rating=TaskComplexity.MODERATE
        ),
        'gpt-4o': ModelInfo(
            name='gpt-4o',
            provider='openai',
            cost_per_1k_input=0.005,
            cost_per_1k_output=0.015,
            context_window=128000,
            strengths=['能力强', '多模态', '推理优秀'],
            weaknesses=['成本较高'],
            complexity_rating=TaskComplexity.COMPLEX
        ),
        'claude-3-haiku': ModelInfo(
            name='claude-3-haiku',
            provider='anthropic',
            cost_per_1k_input=0.00025,
            cost_per_1k_output=0.00125,
            context_window=200000,
            strengths=['速度快', '成本低', '长上下文'],
            weaknesses=['复杂任务能力一般'],
            complexity_rating=TaskComplexity.MODERATE
        ),
        'claude-3-sonnet': ModelInfo(
            name='claude-3-sonnet',
            provider='anthropic',
            cost_per_1k_input=0.003,
            cost_per_1k_output=0.015,
            context_window=200000,
            strengths=['推理能力强', '代码优秀', '长上下文'],
            weaknesses=['成本中等'],
            complexity_rating=TaskComplexity.COMPLEX
        ),
        'claude-3-opus': ModelInfo(
            name='claude-3-opus',
            provider='anthropic',
            cost_per_1k_input=0.015,
            cost_per_1k_output=0.075,
            context_window=200000,
            strengths=['最强推理', '代码顶级', '长上下文'],
            weaknesses=['成本高', '速度慢'],
            complexity_rating=TaskComplexity.VERY_COMPLEX
        ),
    }
    
    # 任务类型到复杂度的映射
    TASK_COMPLEXITY_MAP = {
        '翻译': TaskComplexity.SIMPLE,
        '总结': TaskComplexity.SIMPLE,
        '格式化': TaskComplexity.SIMPLE,
        '简单问答': TaskComplexity.SIMPLE,
        '代码解释': TaskComplexity.MODERATE,
        '代码生成': TaskComplexity.MODERATE,
        '数据分析': TaskComplexity.MODERATE,
        '文档编写': TaskComplexity.MODERATE,
        '复杂推理': TaskComplexity.COMPLEX,
        '系统设计': TaskComplexity.COMPLEX,
        '调试': TaskComplexity.COMPLEX,
        '架构设计': TaskComplexity.VERY_COMPLEX,
        '研究分析': TaskComplexity.VERY_COMPLEX,
    }
    
    @classmethod
    def analyze_complexity(cls, prompt: str, task_type: Optional[str] = None) -> TaskComplexity:
        """
        分析任务复杂度
        
        Args:
            prompt: 用户输入
            task_type: 任务类型（可选）
        
        Returns:
            复杂度等级
        """
        if task_type and task_type in cls.TASK_COMPLEXITY_MAP:
            return cls.TASK_COMPLEXITY_MAP[task_type]
        
        # 基于提示词特征分析
        complexity_score = 0
        prompt_lower = prompt.lower()
        
        # 复杂度指标
        indicators = {
            TaskComplexity.SIMPLE: [
                '翻译', '总结', '概括', '解释', '什么是', '介绍一下'
            ],
            TaskComplexity.MODERATE: [
                '编写', '生成', '创建', '实现', '优化', '改进', '分析'
            ],
            TaskComplexity.COMPLEX: [
                '设计', '架构', '重构', '调试', '排查', '解决', '规划'
            ],
            TaskComplexity.VERY_COMPLEX: [
                '研究', '深入', '全面', '系统性', '架构设计', '技术选型'
            ]
        }
        
        for level, words in indicators.items():
            for word in words:
                if word in prompt_lower:
                    complexity_score = max(complexity_score, level.value)
        
        # 基于长度判断
        if len(prompt) > 2000:
            complexity_score = max(complexity_score, TaskComplexity.COMPLEX.value)
        
        # 基于代码量判断
        code_blocks = prompt.count('```')
        if code_blocks >= 4:
            complexity_score = max(complexity_score, TaskComplexity.COMPLEX.value)
        
        if complexity_score == 0:
            return TaskComplexity.MODERATE
        
        return TaskComplexity(complexity_score)
    
    @classmethod
    def select_model(
        cls, 
        prompt: str, 
        task_type: Optional[str] = None,
        budget_constraint: Optional[float] = None,
        prefer_local: bool = False
    ) -> Dict:
        """
        为任务选择最合适的模型
        
        Args:
            prompt: 用户输入
            task_type: 任务类型
            budget_constraint: 预算限制（美元）
            prefer_local: 是否优先本地模型
        
        Returns:
            推荐的模型信息
        """
        complexity = cls.analyze_complexity(prompt, task_type)
        
        # 筛选符合条件的模型
        candidates = []
        for name, info in cls.MODELS.items():
            # 复杂度匹配
            if info.complexity_rating.value < complexity.value:
                continue
            
            # 预算检查
            if budget_constraint:
                estimated_cost = cls._estimate_cost(prompt, info)
                if estimated_cost > budget_constraint:
                    continue
            
            # 本地模型偏好
            if prefer_local and info.provider != 'ollama':
                score = 0.5
            else:
                score = 1.0
            
            # 性价比评分
            if info.cost_per_1k_input == 0:
                cost_score = 1.0  # 本地模型最高分
            else:
                cost_score = 1.0 / (1 + info.cost_per_1k_input * 100)
            
            # 能力匹配度
            capability_score = 1.0 - abs(info.complexity_rating.value - complexity.value) * 0.2
            
            total_score = score * 0.3 + cost_score * 0.4 + capability_score * 0.3
            
            candidates.append((name, info, total_score))
        
        if not candidates:
            # 如果没有符合条件的，返回最便宜的
            candidates = [
                (name, info, 0) 
                for name, info in cls.MODELS.items()
            ]
        
        # 按评分排序
        candidates.sort(key=lambda x: x[2], reverse=True)
        
        selected = candidates[0]
        alternatives = candidates[1:3]
        
        return {
            'recommended': {
                'name': selected[0],
                'provider': selected[1].provider,
                'reason': cls._get_recommendation_reason(selected[1], complexity),
                'estimated_cost': cls._estimate_cost(prompt, selected[1])
            },
            'alternatives': [
                {
                    'name': alt[0],
                    'provider': alt[1].provider,
                    'reason': f'{"本地模型" if alt[1].provider == "ollama" else "云端模型"}'
                }
                for alt in alternatives
            ],
            'complexity': complexity.name,
            'savings_potential': cls._calculate_savings(selected[1])
        }
    
    @classmethod
    def _estimate_cost(cls, prompt: str, model: ModelInfo) -> float:
        """估算成本"""
        # 假设输入长度，输出约为输入的 50%
        input_tokens = len(prompt) / 4
        output_tokens = input_tokens * 0.5
        
        input_cost = (input_tokens / 1000) * model.cost_per_1k_input
        output_cost = (output_tokens / 1000) * model.cost_per_1k_output
        
        return round(input_cost + output_cost, 4)
    
    @classmethod
    def _get_recommendation_reason(cls, model: ModelInfo, complexity: TaskComplexity) -> str:
        """获取推荐理由"""
        if model.provider == 'ollama':
            return f'本地运行免费，适合{complexity.name}任务'
        elif model.cost_per_1k_input < 0.001:
            return f'成本极低，性价比高'
        elif model.complexity_rating == TaskComplexity.VERY_COMPLEX:
            return f'顶级推理能力，适合复杂任务'
        else:
            return f'能力均衡，成本合理'
    
    @classmethod
    def _calculate_savings(cls, model: ModelInfo) -> str:
        """计算潜在节省"""
        if model.provider == 'ollama':
            return '100% (本地运行完全免费)'
        
        # 对比 GPT-4
        gpt4 = cls.MODELS.get('gpt-4o', list(cls.MODELS.values())[-1])
        if gpt4.cost_per_1k_input == 0:
            return 'N/A'
        
        savings = (1 - model.cost_per_1k_input / gpt4.cost_per_1k_input) * 100
        return f'{savings:.1f}% (相比 GPT-4o)'


def main():
    """CLI 入口"""
    import sys
    import json
    
    if len(sys.argv) < 2:
        print("Usage: model_selector.py <prompt> [--task-type=类型] [--prefer-local]")
        sys.exit(1)
    
    prompt = sys.argv[1]
    task_type = None
    prefer_local = False
    
    for arg in sys.argv[2:]:
        if arg.startswith('--task-type='):
            task_type = arg.split('=')[1]
        elif arg == '--prefer-local':
            prefer_local = True
    
    result = ModelSelector.select_model(prompt, task_type, prefer_local=prefer_local)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()

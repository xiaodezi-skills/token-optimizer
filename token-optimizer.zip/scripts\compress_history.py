#!/usr/bin/env python3
"""
Compress History - 对话历史智能压缩脚本
版本: 1.0.0
作者: 工匠Agent
"""

import json
import re
from typing import List, Dict, Any, Tuple
from dataclasses import dataclass
from datetime import datetime


@dataclass
class CompressionResult:
    """压缩结果"""
    original_tokens: int
    compressed_tokens: int
    compression_ratio: float
    summary: str
    removed_count: int


class HistoryCompressor:
    """对话历史压缩器"""
    
    # 常见冗余模式
    REDUNDANT_PATTERNS = [
        r'^(好的|明白|了解|收到|谢谢|感谢)[，。！]?$',
        r'^(请问|我想问一下|咨询一下)',
        r'^(能否|可以|麻烦|请).*?(吗|么)?[？?]?$',
    ]
    
    # 系统提示词（通常可以压缩）
    SYSTEM_KEYWORDS = [
        'system', 'assistant', '你是', '您的角色', '请扮演',
        'system prompt', 'instruction'
    ]
    
    def __init__(self, aggressive: bool = False):
        self.aggressive = aggressive
        # 估算: 1 token ≈ 4 characters (中文) or 0.75 words (英文)
        self.chars_per_token = 4
    
    def estimate_tokens(self, text: str) -> int:
        """估算Token数"""
        # 简单估算：中文字符按1:1，英文按单词
        chinese_chars = len(re.findall(r'[\u4e00-\u9fff]', text))
        english_words = len(re.findall(r'[a-zA-Z]+', text))
        return chinese_chars + int(english_words * 0.75) + 1
    
    def is_redundant(self, message: Dict[str, Any]) -> bool:
        """检查消息是否冗余"""
        content = message.get('content', '')
        
        # 检查常见冗余模式
        for pattern in self.REDUNDANT_PATTERNS:
            if re.match(pattern, content, re.IGNORECASE):
                return True
        
        # 检查过短的消息
        if len(content) < 10:
            return True
        
        return False
    
    def extract_key_info(self, messages: List[Dict[str, Any]]) -> str:
        """提取关键信息摘要"""
        key_points = []
        
        # 提取用户的主要问题和AI的关键回答
        user_intents = []
        ai_solutions = []
        
        for i, msg in enumerate(messages):
            role = msg.get('role', '')
            content = msg.get('content', '')
            
            if role == 'user':
                # 提取用户意图（首句或关键词）
                first_sentence = content.split('。')[0][:50]
                if len(first_sentence) > 10:
                    user_intents.append(first_sentence)
            
            elif role == 'assistant':
                # 提取AI的关键回答（限制长度）
                if len(content) > 100:
                    # 取首段作为摘要
                    summary = content.split('\n')[0][:100]
                    ai_solutions.append(summary)
                else:
                    ai_solutions.append(content)
        
        # 构建摘要
        if user_intents:
            key_points.append(f"用户主要需求: {'; '.join(user_intents[-2:])}")
        if ai_solutions:
            key_points.append(f"AI核心回答: {'; '.join(ai_solutions[-2:])}")
        
        return '\n'.join(key_points) if key_points else "对话内容已压缩"
    
    def compress(self, messages: List[Dict[str, Any]]) -> Tuple[List[Dict[str, Any]], CompressionResult]:
        """
        压缩对话历史
        
        策略:
        1. 移除冗余消息
        2. 合并相似消息
        3. 对旧消息生成摘要
        4. 保留最近的完整上下文
        """
        if not messages:
            return messages, CompressionResult(0, 0, 0, "无内容", 0)
        
        original_text = '\n'.join(m.get('content', '') for m in messages)
        original_tokens = self.estimate_tokens(original_text)
        
        # 保留最近的消息数量
        keep_recent = 4 if self.aggressive else 6
        
        # 分离最近消息和历史消息
        recent_messages = messages[-keep_recent:] if len(messages) > keep_recent else messages
        history_messages = messages[:-keep_recent] if len(messages) > keep_recent else []
        
        # 过滤历史消息中的冗余内容
        filtered_history = [m for m in history_messages if not self.is_redundant(m)]
        
        # 对历史消息生成摘要
        compressed_messages = []
        removed_count = len(history_messages) - len(filtered_history)
        
        if filtered_history:
            summary = self.extract_key_info(filtered_history)
            compressed_messages.append({
                'role': 'system',
                'content': f'[历史对话摘要] {summary}',
                'compressed': True,
                'original_count': len(history_messages)
            })
            removed_count += len(filtered_history)
        
        # 添加最近完整消息
        compressed_messages.extend(recent_messages)
        
        # 计算压缩结果
        compressed_text = '\n'.join(m.get('content', '') for m in compressed_messages)
        compressed_tokens = self.estimate_tokens(compressed_text)
        
        compression_ratio = (original_tokens - compressed_tokens) / original_tokens if original_tokens > 0 else 0
        
        result = CompressionResult(
            original_tokens=original_tokens,
            compressed_tokens=compressed_tokens,
            compression_ratio=round(compression_ratio, 2),
            summary=f"从 {len(messages)} 条消息压缩为 {len(compressed_messages)} 条",
            removed_count=removed_count
        )
        
        return compressed_messages, result
    
    def smart_compress(self, messages: List[Dict[str, Any]], 
                       target_ratio: float = 0.5) -> Tuple[List[Dict[str, Any]], CompressionResult]:
        """
        智能压缩：根据目标压缩率自动调整策略
        
        Args:
            messages: 原始消息列表
            target_ratio: 目标压缩率 (0-1)
        
        Returns:
            压缩后的消息列表和结果
        """
        # 先尝试标准压缩
        compressed, result = self.compress(messages)
        
        # 如果未达到目标压缩率，启用激进模式
        if result.compression_ratio < target_ratio:
            self.aggressive = True
            compressed, result = self.compress(messages)
        
        return compressed, result


class SessionOptimizer:
    """会话优化器"""
    
    def __init__(self):
        self.compressor = HistoryCompressor()
    
    def optimize_session(self, session_data: Dict[str, Any]) -> Dict[str, Any]:
        """优化单个会话"""
        messages = session_data.get('messages', [])
        
        if len(messages) <= 4:
            return session_data  # 消息太少，无需优化
        
        compressed_messages, result = self.compressor.compress(messages)
        
        optimized = session_data.copy()
        optimized['messages'] = compressed_messages
        optimized['compression'] = {
            'original_tokens': result.original_tokens,
            'compressed_tokens': result.compressed_tokens,
            'saved_tokens': result.original_tokens - result.compressed_tokens,
            'compression_ratio': result.compression_ratio,
            'optimized_at': datetime.now().isoformat()
        }
        
        return optimized
    
    def batch_optimize(self, sessions: List[Dict[str, Any]]) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
        """批量优化会话"""
        optimized_sessions = []
        total_original = 0
        total_compressed = 0
        
        for session in sessions:
            optimized = self.optimize_session(session)
            optimized_sessions.append(optimized)
            
            if 'compression' in optimized:
                total_original += optimized['compression']['original_tokens']
                total_compressed += optimized['compression']['compressed_tokens']
        
        summary = {
            'total_sessions': len(sessions),
            'optimized_sessions': len([s for s in optimized_sessions if 'compression' in s]),
            'total_original_tokens': total_original,
            'total_compressed_tokens': total_compressed,
            'total_saved_tokens': total_original - total_compressed,
            'overall_compression_ratio': round((total_original - total_compressed) / total_original, 2) if total_original > 0 else 0
        }
        
        return optimized_sessions, summary


def main():
    """命令行入口"""
    import argparse
    
    parser = argparse.ArgumentParser(description='History Compressor')
    parser.add_argument('action', choices=['compress', 'analyze', 'batch'])
    parser.add_argument('--input', '-i', help='输入文件路径')
    parser.add_argument('--output', '-o', help='输出文件路径')
    parser.add_argument('--aggressive', '-a', action='store_true', help='激进模式')
    parser.add_argument('--target-ratio', '-t', type=float, default=0.5, help='目标压缩率')
    
    args = parser.parse_args()
    
    compressor = HistoryCompressor(aggressive=args.aggressive)
    
    if args.action == 'compress':
        if not args.input:
            print("❌ 请指定输入文件: --input")
            return
        
        with open(args.input, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        messages = data.get('messages', [])
        compressed, result = compressor.smart_compress(messages, args.target_ratio)
        
        output_data = {
            'messages': compressed,
            'compression_result': {
                'original_tokens': result.original_tokens,
                'compressed_tokens': result.compressed_tokens,
                'saved_tokens': result.original_tokens - result.compressed_tokens,
                'compression_ratio': result.compression_ratio,
                'summary': result.summary
            }
        }
        
        if args.output:
            with open(args.output, 'w', encoding='utf-8') as f:
                json.dump(output_data, f, indent=2, ensure_ascii=False)
            print(f"✅ 已保存到: {args.output}")
        else:
            print(json.dumps(output_data, indent=2, ensure_ascii=False))
        
        print(f"\n📊 压缩结果:")
        print(f"   原始Token: {result.original_tokens}")
        print(f"   压缩后Token: {result.compressed_tokens}")
        print(f"   节省Token: {result.original_tokens - result.compressed_tokens}")
        print(f"   压缩率: {result.compression_ratio*100:.1f}%")
    
    elif args.action == 'analyze':
        if not args.input:
            print("❌ 请指定输入文件: --input")
            return
        
        with open(args.input, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        messages = data.get('messages', [])
        total_tokens = sum(compressor.estimate_tokens(m.get('content', '')) for m in messages)
        redundant_count = sum(1 for m in messages if compressor.is_redundant(m))
        
        print(f"📊 会话分析:")
        print(f"   消息总数: {len(messages)}")
        print(f"   估算Token: {total_tokens}")
        print(f"   冗余消息: {redundant_count}")
        print(f"   预估可节省: {int(redundant_count / len(messages) * total_tokens) if messages else 0} tokens")
    
    elif args.action == 'batch':
        print("📦 批量优化模式")
        print("   请提供包含多个会话的JSON文件")


if __name__ == '__main__':
    main()
